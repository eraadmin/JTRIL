prompt --application/shared_components/logic/application_items/item_cntr_fntclr
begin
--   Manifest
--     APPLICATION ITEM: ITEM_CNTR_FNTCLR
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.10.15'
,p_release=>'21.2.0'
,p_default_workspace_id=>100100
,p_default_application_id=>100100
,p_default_id_offset=>172555406974799196
,p_default_owner=>'ORBRGS_DMO'
);
wwv_flow_api.create_flow_item(
 p_id=>wwv_flow_api.id(72419725601094195)
,p_name=>'ITEM_CNTR_FNTCLR'
,p_scope=>'GLOBAL'
,p_protection_level=>'N'
,p_escape_on_http_output=>'N'
);
wwv_flow_api.component_end;
end;
/
